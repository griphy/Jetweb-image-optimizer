<?php
/**
 * Bulk Optimizer - Process all existing images
 */

if (!defined('ABSPATH')) {
    exit;
}

class JetWeb_IO_Bulk_Optimizer {

    public function init() {
        add_action('wp_ajax_jetweb_io_bulk_get_images', [$this, 'ajax_get_unoptimized']);
        add_action('wp_ajax_jetweb_io_bulk_optimize', [$this, 'ajax_bulk_optimize_batch']);
    }

    /**
     * Get list of unoptimized image attachment IDs
     */
    public function ajax_get_unoptimized() {
        check_ajax_referer('jetweb_io_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permission denied');
        }

        global $wpdb;

        $stats_table = $wpdb->prefix . 'jetweb_io_stats';

        // Get all image attachments not yet optimized
        $all_images = $wpdb->get_col("
            SELECT p.ID
            FROM {$wpdb->posts} p
            WHERE p.post_type = 'attachment'
            AND p.post_mime_type IN ('image/jpeg', 'image/png', 'image/gif', 'image/bmp')
            AND p.ID NOT IN (
                SELECT DISTINCT attachment_id FROM {$stats_table}
            )
            ORDER BY p.ID DESC
        ");

        wp_send_json_success([
            'image_ids' => array_map('intval', $all_images),
            'total'     => count($all_images),
        ]);
    }

    /**
     * Optimize a batch of images via AJAX
     */
    public function ajax_bulk_optimize_batch() {
        check_ajax_referer('jetweb_io_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permission denied');
        }

        $attachment_ids = array_map('intval', $_POST['attachment_ids'] ?? []);
        if (empty($attachment_ids)) {
            wp_send_json_error('No images to process');
        }

        $options = get_option('jetweb_io_settings', []);
        $converter = new JetWeb_IO_Converter();
        $compressor = new JetWeb_IO_Compressor();
        $stats_handler = new JetWeb_IO_Stats();
        $results = [];

        foreach ($attachment_ids as $id) {
            $file = get_attached_file($id);
            if (!$file || !file_exists($file)) {
                $results[$id] = ['status' => 'error', 'message' => 'File not found'];
                continue;
            }

            // Compress original
            if (!empty($options['compress_originals'])) {
                $compressor->compress_file($file);
            }

            // Convert
            $converted = $converter->convert($file, $options);
            if ($converted) {
                $stats_handler->record_conversion($id, $file, $converted);

                // Process thumbnails
                $metadata = wp_get_attachment_metadata($id);
                if (!empty($metadata['sizes'])) {
                    $dir = dirname($file);
                    foreach ($metadata['sizes'] as $size_data) {
                        $thumb = trailingslashit($dir) . $size_data['file'];
                        if (file_exists($thumb)) {
                            $tc = $converter->convert($thumb, $options);
                            if ($tc) {
                                $stats_handler->record_conversion($id, $thumb, $tc);
                            }
                        }
                    }
                }

                $attachment_stats = $stats_handler->get_attachment_stats($id);
                $results[$id] = [
                    'status'  => 'success',
                    'savings' => $attachment_stats ? round($attachment_stats->savings_percent, 1) : 0,
                ];
            } else {
                $results[$id] = ['status' => 'error', 'message' => 'Conversion failed'];
            }
        }

        wp_send_json_success([
            'results' => $results,
            'summary' => $stats_handler->get_summary(),
        ]);
    }
}
