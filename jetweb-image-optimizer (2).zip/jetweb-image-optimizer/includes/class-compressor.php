<?php
/**
 * Image Compressor - Compresses original images
 */

if (!defined('ABSPATH')) {
    exit;
}

class JetWeb_IO_Compressor {

    /**
     * Compress a file in-place (or create backup first)
     */
    public function compress_file($file_path) {
        if (!file_exists($file_path)) {
            return false;
        }

        $options = get_option('jetweb_io_settings', []);
        $preserve = $options['preserve_originals'] ?? true;
        $max_width = $options['max_width'] ?? 2560;
        $max_height = $options['max_height'] ?? 2560;

        // Backup original if setting enabled
        if ($preserve) {
            $this->backup_original($file_path);
        }

        $mime = wp_get_image_mime($file_path);

        // Resize if exceeds max dimensions
        $this->maybe_resize($file_path, $max_width, $max_height);

        // Compress based on type
        switch ($mime) {
            case 'image/jpeg':
                return $this->compress_jpeg($file_path, $options['jpeg_quality'] ?? 82);
            case 'image/png':
                return $this->compress_png($file_path, $options['png_compression'] ?? 9);
            case 'image/gif':
                return $this->optimize_gif($file_path);
            default:
                return false;
        }
    }

    /**
     * Compress JPEG
     */
    private function compress_jpeg($file_path, $quality = 82) {
        if (extension_loaded('imagick')) {
            return $this->imagick_compress_jpeg($file_path, $quality);
        }
        return $this->gd_compress_jpeg($file_path, $quality);
    }

    private function gd_compress_jpeg($file_path, $quality) {
        $image = @imagecreatefromjpeg($file_path);
        if (!$image) {
            return false;
        }

        // Strip EXIF by re-saving (GD doesn't preserve EXIF by default)
        $result = imagejpeg($image, $file_path, $quality);
        imagedestroy($image);
        return $result;
    }

    private function imagick_compress_jpeg($file_path, $quality) {
        try {
            $imagick = new Imagick($file_path);

            // Strip metadata
            $imagick->stripImage();

            // Set sampling factor for better compression
            $imagick->setSamplingFactors(['2x2', '1x1', '1x1']);

            // Interlace for progressive JPEG
            $imagick->setInterlaceScheme(Imagick::INTERLACE_PLANE);

            // Compression quality
            $imagick->setImageCompressionQuality($quality);

            $imagick->writeImage($file_path);
            $imagick->clear();
            $imagick->destroy();

            return true;
        } catch (Exception $e) {
            error_log('JetWeb IO JPEG compression error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Compress PNG
     */
    private function compress_png($file_path, $compression = 9) {
        if (extension_loaded('imagick')) {
            return $this->imagick_compress_png($file_path, $compression);
        }
        return $this->gd_compress_png($file_path, $compression);
    }

    private function gd_compress_png($file_path, $compression) {
        $image = @imagecreatefrompng($file_path);
        if (!$image) {
            return false;
        }

        // Preserve alpha
        imagealphablending($image, false);
        imagesavealpha($image, true);

        $result = imagepng($image, $file_path, $compression);
        imagedestroy($image);
        return $result;
    }

    private function imagick_compress_png($file_path, $compression) {
        try {
            $imagick = new Imagick($file_path);
            $imagick->stripImage();
            $imagick->setImageCompressionQuality($compression * 10);
            $imagick->writeImage($file_path);
            $imagick->clear();
            $imagick->destroy();
            return true;
        } catch (Exception $e) {
            error_log('JetWeb IO PNG compression error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Optimize GIF (strip comments and metadata)
     */
    private function optimize_gif($file_path) {
        if (!extension_loaded('imagick')) {
            return false;
        }

        try {
            $imagick = new Imagick($file_path);
            $imagick->stripImage();
            $imagick->writeImages($file_path, true);
            $imagick->clear();
            $imagick->destroy();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Resize image if it exceeds maximum dimensions
     */
    private function maybe_resize($file_path, $max_width, $max_height) {
        if ($max_width <= 0 && $max_height <= 0) {
            return false;
        }

        $size = @getimagesize($file_path);
        if (!$size) {
            return false;
        }

        $orig_w = $size[0];
        $orig_h = $size[1];

        // No resize needed
        if ($orig_w <= $max_width && $orig_h <= $max_height) {
            return false;
        }

        // Use WordPress built-in image editor
        $editor = wp_get_image_editor($file_path);
        if (is_wp_error($editor)) {
            return false;
        }

        $editor->resize($max_width, $max_height, false);
        $result = $editor->save($file_path);

        return !is_wp_error($result);
    }

    /**
     * Backup original file
     */
    private function backup_original($file_path) {
        $upload_dir = wp_upload_dir();
        $backup_dir = trailingslashit($upload_dir['basedir']) . 'jetweb-io-backups';

        if (!file_exists($backup_dir)) {
            wp_mkdir_p($backup_dir);
        }

        // Create relative structure in backup dir
        $relative = str_replace($upload_dir['basedir'], '', $file_path);
        $backup_path = $backup_dir . $relative;
        $backup_file_dir = dirname($backup_path);

        if (!file_exists($backup_file_dir)) {
            wp_mkdir_p($backup_file_dir);
        }

        // Only backup if not already backed up
        if (!file_exists($backup_path)) {
            return @copy($file_path, $backup_path);
        }

        return true;
    }

    /**
     * Restore original from backup
     */
    public function restore_original($file_path) {
        $upload_dir = wp_upload_dir();
        $backup_dir = trailingslashit($upload_dir['basedir']) . 'jetweb-io-backups';
        $relative = str_replace($upload_dir['basedir'], '', $file_path);
        $backup_path = $backup_dir . $relative;

        if (file_exists($backup_path)) {
            return @copy($backup_path, $file_path);
        }

        return false;
    }
}
