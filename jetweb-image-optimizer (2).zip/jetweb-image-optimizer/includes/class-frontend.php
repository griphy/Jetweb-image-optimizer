<?php
/**
 * Frontend - Serves modern image formats to supporting browsers
 */

if (!defined('ABSPATH')) {
    exit;
}

class JetWeb_IO_Frontend {

    public function init() {
        $options = get_option('jetweb_io_settings', []);

        if (!empty($options['auto_serve'])) {
            // Rewrite image URLs in content
            add_filter('the_content', [$this, 'rewrite_content_images'], 999);
            add_filter('post_thumbnail_html', [$this, 'rewrite_content_images'], 999);
            add_filter('wp_get_attachment_image', [$this, 'rewrite_content_images'], 999);

            // Use <picture> element for better browser support
            add_filter('wp_content_img_tag', [$this, 'add_picture_element'], 10, 3);
        }

        if (!empty($options['lazy_loading'])) {
            add_filter('wp_img_tag_add_loading_attr', [$this, 'add_lazy_loading'], 10, 3);
        }

        // Add preconnect/preload hints
        add_action('wp_head', [$this, 'add_resource_hints'], 1);
    }

    /**
     * Rewrite image URLs in content to use modern formats
     */
    public function rewrite_content_images($content) {
        if (empty($content)) {
            return $content;
        }

        // Match all img tags
        $content = preg_replace_callback(
            '/<img\s[^>]*src=["\']([^"\']+)["\'][^>]*>/i',
            [$this, 'maybe_replace_image_tag'],
            $content
        );

        // Also handle srcset attributes
        $content = preg_replace_callback(
            '/srcset=["\']([^"\']+)["\']/i',
            [$this, 'rewrite_srcset'],
            $content
        );

        return $content;
    }

    /**
     * Replace img tag with picture element for format fallback
     */
    public function add_picture_element($filtered_image, $context, $attachment_id) {
        if (empty($filtered_image) || $context !== 'the_content') {
            return $filtered_image;
        }

        // Extract src from img tag
        if (!preg_match('/src=["\']([^"\']+)["\']/i', $filtered_image, $matches)) {
            return $filtered_image;
        }

        $original_src = $matches[1];
        $upload_dir = wp_upload_dir();
        $base_url = $upload_dir['baseurl'];
        $base_dir = $upload_dir['basedir'];

        // Only process images from our uploads directory
        if (strpos($original_src, $base_url) === false) {
            return $filtered_image;
        }

        $relative_path = str_replace($base_url, '', $original_src);
        $file_path = $base_dir . $relative_path;
        $sources = [];

        // Check for AVIF version
        $avif_path = $this->get_modern_path($file_path, 'avif');
        if ($avif_path && file_exists($avif_path)) {
            $avif_url = str_replace($base_dir, $base_url, $avif_path);
            $sources[] = '<source srcset="' . esc_url($avif_url) . '" type="image/avif">';
        }

        // Check for WebP version
        $webp_path = $this->get_modern_path($file_path, 'webp');
        if ($webp_path && file_exists($webp_path)) {
            $webp_url = str_replace($base_dir, $base_url, $webp_path);
            $sources[] = '<source srcset="' . esc_url($webp_url) . '" type="image/webp">';
        }

        // If no modern formats available, return original
        if (empty($sources)) {
            return $filtered_image;
        }

        // Build <picture> element
        $picture = '<picture>' . "\n";
        $picture .= implode("\n", $sources) . "\n";
        $picture .= $filtered_image . "\n";
        $picture .= '</picture>';

        return $picture;
    }

    /**
     * Replace individual img src if modern format exists
     */
    private function maybe_replace_image_tag($matches) {
        $full_tag = $matches[0];
        $src = $matches[1];

        $browser_format = $this->get_best_format();
        if (!$browser_format) {
            return $full_tag;
        }

        $upload_dir = wp_upload_dir();
        $base_url = $upload_dir['baseurl'];
        $base_dir = $upload_dir['basedir'];

        if (strpos($src, $base_url) === false) {
            return $full_tag;
        }

        $relative = str_replace($base_url, '', $src);
        $file_path = $base_dir . $relative;

        $modern_path = $this->get_modern_path($file_path, $browser_format);
        if ($modern_path && file_exists($modern_path)) {
            $modern_url = str_replace($base_dir, $base_url, $modern_path);
            return str_replace($src, $modern_url, $full_tag);
        }

        return $full_tag;
    }

    /**
     * Rewrite srcset URLs to point to modern formats
     */
    private function rewrite_srcset($matches) {
        $srcset = $matches[1];
        $browser_format = $this->get_best_format();

        if (!$browser_format) {
            return $matches[0];
        }

        $upload_dir = wp_upload_dir();
        $base_url = $upload_dir['baseurl'];
        $base_dir = $upload_dir['basedir'];

        $sources = explode(',', $srcset);
        $new_sources = [];

        foreach ($sources as $source) {
            $source = trim($source);
            $parts = preg_split('/\s+/', $source);
            $url = $parts[0];
            $descriptor = isset($parts[1]) ? $parts[1] : '';

            if (strpos($url, $base_url) !== false) {
                $relative = str_replace($base_url, '', $url);
                $file_path = $base_dir . $relative;
                $modern_path = $this->get_modern_path($file_path, $browser_format);

                if ($modern_path && file_exists($modern_path)) {
                    $url = str_replace($base_dir, $base_url, $modern_path);
                }
            }

            $new_sources[] = $url . ($descriptor ? ' ' . $descriptor : '');
        }

        return 'srcset="' . implode(', ', $new_sources) . '"';
    }

    /**
     * Determine the best image format for the current browser
     */
    private function get_best_format() {
        if (!isset($_SERVER['HTTP_ACCEPT'])) {
            return false;
        }

        $accept = $_SERVER['HTTP_ACCEPT'];

        // AVIF is preferred over WebP (smaller files, better quality)
        if (strpos($accept, 'image/avif') !== false) {
            return 'avif';
        }

        if (strpos($accept, 'image/webp') !== false) {
            return 'webp';
        }

        return false;
    }

    /**
     * Get path for modern format version
     */
    private function get_modern_path($file_path, $format) {
        $dir = dirname($file_path);
        $filename = pathinfo($file_path, PATHINFO_FILENAME);
        return trailingslashit($dir) . $filename . '.' . $format;
    }

    /**
     * Add lazy loading attribute
     */
    public function add_lazy_loading($value, $image, $context) {
        return 'lazy';
    }

    /**
     * Add resource hints for performance
     */
    public function add_resource_hints() {
        $upload_dir = wp_upload_dir();
        $upload_url = $upload_dir['baseurl'];
        $parsed = wp_parse_url($upload_url);

        if (!empty($parsed['host']) && $parsed['host'] !== wp_parse_url(home_url(), PHP_URL_HOST)) {
            echo '<link rel="preconnect" href="' . esc_url($parsed['scheme'] . '://' . $parsed['host']) . '">' . "\n";
        }
    }
}
