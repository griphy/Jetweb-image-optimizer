<?php
/**
 * Image Converter - Converts images to WebP and AVIF formats
 */

if (!defined('ABSPATH')) {
    exit;
}

class JetWeb_IO_Converter {

    private $use_imagick;

    public function __construct() {
        $this->use_imagick = extension_loaded('imagick') && class_exists('Imagick');
    }

    /**
     * Convert an image to modern format(s)
     *
     * @param string $file_path Path to the source image
     * @param array  $options   Plugin settings
     * @return array|false Array of converted file paths or false on failure
     */
    public function convert($file_path, $options = []) {
        if (!file_exists($file_path)) {
            return false;
        }

        $options = wp_parse_args($options, [
            'output_format'      => 'webp',
            'webp_quality'       => 82,
            'avif_quality'       => 65,
            'preserve_originals' => true,
        ]);

        $results = [];
        $format = $options['output_format'];

        if ($format === 'webp' || $format === 'both') {
            $webp_path = $this->convert_to_webp($file_path, $options['webp_quality']);
            if ($webp_path) {
                $results['webp'] = $webp_path;
            }
        }

        if ($format === 'avif' || $format === 'both') {
            $avif_path = $this->convert_to_avif($file_path, $options['avif_quality']);
            if ($avif_path) {
                $results['avif'] = $avif_path;
            }
        }

        return !empty($results) ? $results : false;
    }

    /**
     * Convert image to WebP
     */
    public function convert_to_webp($source_path, $quality = 82) {
        $output_path = $this->get_output_path($source_path, 'webp');

        // Skip if already exists and source hasn't changed
        if (file_exists($output_path) && filemtime($output_path) >= filemtime($source_path)) {
            return $output_path;
        }

        if ($this->use_imagick) {
            return $this->imagick_convert($source_path, $output_path, 'webp', $quality);
        }

        return $this->gd_convert_to_webp($source_path, $output_path, $quality);
    }

    /**
     * Convert image to AVIF
     */
    public function convert_to_avif($source_path, $quality = 65) {
        $output_path = $this->get_output_path($source_path, 'avif');

        if (file_exists($output_path) && filemtime($output_path) >= filemtime($source_path)) {
            return $output_path;
        }

        // AVIF support check
        if ($this->use_imagick) {
            $formats = Imagick::queryFormats('AVIF');
            if (!empty($formats)) {
                return $this->imagick_convert($source_path, $output_path, 'avif', $quality);
            }
        }

        // GD AVIF support (PHP 8.1+)
        if (function_exists('imageavif')) {
            return $this->gd_convert_to_avif($source_path, $output_path, $quality);
        }

        // Try cwebp/avifenc command line tools as fallback
        return $this->cli_convert_to_avif($source_path, $output_path, $quality);
    }

    /**
     * GD-based WebP conversion
     */
    private function gd_convert_to_webp($source_path, $output_path, $quality) {
        $image = $this->gd_load_image($source_path);
        if (!$image) {
            return false;
        }

        // Preserve alpha channel
        imagepalettetotruecolor($image);
        imagealphablending($image, true);
        imagesavealpha($image, true);

        $result = imagewebp($image, $output_path, $quality);
        imagedestroy($image);

        if ($result && file_exists($output_path)) {
            // WebP bug: files < 6 bytes are invalid
            if (filesize($output_path) < 6) {
                @unlink($output_path);
                return false;
            }
            return $output_path;
        }

        return false;
    }

    /**
     * GD-based AVIF conversion (PHP 8.1+)
     */
    private function gd_convert_to_avif($source_path, $output_path, $quality) {
        if (!function_exists('imageavif')) {
            return false;
        }

        $image = $this->gd_load_image($source_path);
        if (!$image) {
            return false;
        }

        imagepalettetotruecolor($image);
        imagealphablending($image, true);
        imagesavealpha($image, true);

        // Speed 6 is a good balance (0=slowest/best, 10=fastest/worst)
        $result = imageavif($image, $output_path, $quality, 6);
        imagedestroy($image);

        return ($result && file_exists($output_path)) ? $output_path : false;
    }

    /**
     * Imagick-based conversion
     */
    private function imagick_convert($source_path, $output_path, $format, $quality) {
        try {
            $imagick = new Imagick($source_path);

            // Strip metadata to save space
            $imagick->stripImage();

            // Set format
            $imagick->setImageFormat($format);
            $imagick->setImageCompressionQuality($quality);

            // AVIF-specific optimizations
            if ($format === 'avif') {
                $imagick->setOption('heic:speed', '6');
            }

            // Handle alpha for WebP
            if ($format === 'webp') {
                $imagick->setOption('webp:lossless', 'false');
                $imagick->setOption('webp:method', '6');
                $imagick->setOption('webp:alpha-quality', '85');
            }

            $result = $imagick->writeImage($output_path);
            $imagick->clear();
            $imagick->destroy();

            return ($result && file_exists($output_path)) ? $output_path : false;

        } catch (Exception $e) {
            error_log('JetWeb IO Imagick Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * CLI fallback for AVIF using avifenc
     */
    private function cli_convert_to_avif($source_path, $output_path, $quality) {
        // Check if avifenc is available
        $avifenc = trim(shell_exec('which avifenc 2>/dev/null'));
        if (empty($avifenc)) {
            return false;
        }

        // First convert to PNG if needed (avifenc prefers PNG/Y4M input)
        $ext = strtolower(pathinfo($source_path, PATHINFO_EXTENSION));
        $temp_png = null;

        if (!in_array($ext, ['png', 'y4m'])) {
            $temp_png = tempnam(sys_get_temp_dir(), 'jetweb_') . '.png';
            $image = $this->gd_load_image($source_path);
            if ($image) {
                imagepng($image, $temp_png);
                imagedestroy($image);
                $source_path = $temp_png;
            }
        }

        $min_q = max(0, $quality - 10);
        $max_q = min(63, $quality);

        $cmd = sprintf(
            '%s -j 4 --min %d --max %d --speed 6 -o %s %s 2>&1',
            escapeshellcmd($avifenc),
            $min_q,
            $max_q,
            escapeshellarg($output_path),
            escapeshellarg($source_path)
        );

        exec($cmd, $output, $return_var);

        // Clean up temp file
        if ($temp_png && file_exists($temp_png)) {
            @unlink($temp_png);
        }

        return ($return_var === 0 && file_exists($output_path)) ? $output_path : false;
    }

    /**
     * Load image with GD based on file type
     */
    private function gd_load_image($file_path) {
        $mime = wp_get_image_mime($file_path);

        switch ($mime) {
            case 'image/jpeg':
                return @imagecreatefromjpeg($file_path);
            case 'image/png':
                return @imagecreatefrompng($file_path);
            case 'image/gif':
                return @imagecreatefromgif($file_path);
            case 'image/bmp':
            case 'image/x-ms-bmp':
                return function_exists('imagecreatefrombmp') ? @imagecreatefrombmp($file_path) : false;
            case 'image/webp':
                return function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($file_path) : false;
            default:
                return false;
        }
    }

    /**
     * Get the output path for a converted file
     */
    public function get_output_path($source_path, $format) {
        $dir = dirname($source_path);
        $filename = pathinfo($source_path, PATHINFO_FILENAME);
        return trailingslashit($dir) . $filename . '.' . $format;
    }

    /**
     * Check which formats are supported on this server
     */
    public static function get_supported_formats() {
        $formats = [];

        // WebP support
        if (extension_loaded('imagick')) {
            $imagick_formats = Imagick::queryFormats('WEBP');
            if (!empty($imagick_formats)) {
                $formats['webp'] = 'imagick';
            }
        }
        if (!isset($formats['webp']) && function_exists('imagewebp')) {
            $formats['webp'] = 'gd';
        }

        // AVIF support
        if (extension_loaded('imagick')) {
            $imagick_formats = Imagick::queryFormats('AVIF');
            if (!empty($imagick_formats)) {
                $formats['avif'] = 'imagick';
            }
        }
        if (!isset($formats['avif']) && function_exists('imageavif')) {
            $formats['avif'] = 'gd';
        }
        if (!isset($formats['avif'])) {
            $avifenc = trim(shell_exec('which avifenc 2>/dev/null') ?? '');
            if (!empty($avifenc)) {
                $formats['avif'] = 'cli';
            }
        }

        return $formats;
    }
}
