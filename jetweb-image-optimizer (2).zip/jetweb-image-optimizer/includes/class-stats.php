<?php
/**
 * Stats Tracker - Records and retrieves optimization statistics
 */

if (!defined('ABSPATH')) {
    exit;
}

class JetWeb_IO_Stats {

    private $table_name;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'jetweb_io_stats';
    }

    /**
     * Record a conversion result
     */
    public function record_conversion($attachment_id, $original_path, $converted_paths) {
        global $wpdb;

        $original_size = file_exists($original_path) ? filesize($original_path) : 0;

        foreach ($converted_paths as $format => $converted_path) {
            if (!file_exists($converted_path)) {
                continue;
            }

            $converted_size = filesize($converted_path);
            $savings = $original_size > 0 ? (($original_size - $converted_size) / $original_size) * 100 : 0;

            // Upsert: delete existing record for same file+format, then insert
            $wpdb->delete($this->table_name, [
                'attachment_id' => $attachment_id,
                'original_path' => $original_path,
                'format'        => $format,
            ]);

            $wpdb->insert($this->table_name, [
                'attachment_id'  => $attachment_id,
                'original_path'  => $original_path,
                'converted_path' => $converted_path,
                'original_size'  => $original_size,
                'converted_size' => $converted_size,
                'savings_percent'=> round($savings, 2),
                'format'         => $format,
            ]);
        }
    }

    /**
     * Get stats for a specific attachment
     */
    public function get_attachment_stats($attachment_id) {
        global $wpdb;

        return $wpdb->get_row($wpdb->prepare(
            "SELECT *, (original_size - converted_size) as bytes_saved
             FROM {$this->table_name}
             WHERE attachment_id = %d
             ORDER BY savings_percent DESC
             LIMIT 1",
            $attachment_id
        ));
    }

    /**
     * Delete stats for an attachment
     */
    public function delete_attachment_stats($attachment_id) {
        global $wpdb;
        $wpdb->delete($this->table_name, ['attachment_id' => $attachment_id]);
    }

    /**
     * Get overall summary stats
     */
    public function get_summary() {
        global $wpdb;

        $row = $wpdb->get_row("
            SELECT
                COUNT(DISTINCT attachment_id) as total_images,
                COALESCE(SUM(original_size), 0) as total_original,
                COALESCE(SUM(converted_size), 0) as total_converted,
                COALESCE(AVG(savings_percent), 0) as avg_savings
            FROM {$this->table_name}
        ");

        $total_saved = ($row->total_original ?? 0) - ($row->total_converted ?? 0);

        return [
            'total_images'        => intval($row->total_images ?? 0),
            'total_original'      => intval($row->total_original ?? 0),
            'total_converted'     => intval($row->total_converted ?? 0),
            'total_saved'         => max(0, $total_saved),
            'total_saved_readable'=> size_format(max(0, $total_saved)),
            'avg_savings'         => round($row->avg_savings ?? 0, 1),
        ];
    }
}
