<?php
/**
 * Admin Settings Page
 */

if (!defined('ABSPATH')) {
    exit;
}

class JetWeb_IO_Admin {

    public function init() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_filter('plugin_action_links_' . JETWEB_IO_PLUGIN_BASENAME, [$this, 'add_action_links']);

        // Media library column
        add_filter('manage_media_columns', [$this, 'add_media_column']);
        add_action('manage_media_custom_column', [$this, 'render_media_column'], 10, 2);

        // AJAX handlers
        add_action('wp_ajax_jetweb_io_optimize_single', [$this, 'ajax_optimize_single']);
        add_action('wp_ajax_jetweb_io_restore_single', [$this, 'ajax_restore_single']);
        add_action('wp_ajax_jetweb_io_get_stats', [$this, 'ajax_get_stats']);
    }

    public function add_menu() {
        add_options_page(
            __('JetWeb Image Optimizer', 'jetweb-image-optimizer'),
            __('Image Optimizer', 'jetweb-image-optimizer'),
            'manage_options',
            'jetweb-image-optimizer',
            [$this, 'render_settings_page']
        );
    }

    public function register_settings() {
        register_setting('jetweb_io_settings_group', 'jetweb_io_settings', [
            'sanitize_callback' => [$this, 'sanitize_settings'],
        ]);

        // Conversion Settings
        add_settings_section('jetweb_io_conversion', __('Format Conversion', 'jetweb-image-optimizer'), null, 'jetweb-image-optimizer');

        add_settings_field('output_format', __('Output Format', 'jetweb-image-optimizer'), [$this, 'render_format_field'], 'jetweb-image-optimizer', 'jetweb_io_conversion');
        add_settings_field('webp_quality', __('WebP Quality', 'jetweb-image-optimizer'), [$this, 'render_webp_quality_field'], 'jetweb-image-optimizer', 'jetweb_io_conversion');
        add_settings_field('avif_quality', __('AVIF Quality', 'jetweb-image-optimizer'), [$this, 'render_avif_quality_field'], 'jetweb-image-optimizer', 'jetweb_io_conversion');

        // Compression Settings
        add_settings_section('jetweb_io_compression', __('Compression', 'jetweb-image-optimizer'), null, 'jetweb-image-optimizer');

        add_settings_field('compress_originals', __('Compress Originals', 'jetweb-image-optimizer'), [$this, 'render_compress_originals_field'], 'jetweb-image-optimizer', 'jetweb_io_compression');
        add_settings_field('jpeg_quality', __('JPEG Quality', 'jetweb-image-optimizer'), [$this, 'render_jpeg_quality_field'], 'jetweb-image-optimizer', 'jetweb_io_compression');
        add_settings_field('max_dimensions', __('Max Dimensions', 'jetweb-image-optimizer'), [$this, 'render_max_dimensions_field'], 'jetweb-image-optimizer', 'jetweb_io_compression');

        // Delivery Settings
        add_settings_section('jetweb_io_delivery', __('Delivery', 'jetweb-image-optimizer'), null, 'jetweb-image-optimizer');

        add_settings_field('auto_serve', __('Auto-Serve Modern Formats', 'jetweb-image-optimizer'), [$this, 'render_auto_serve_field'], 'jetweb-image-optimizer', 'jetweb_io_delivery');
        add_settings_field('lazy_loading', __('Lazy Loading', 'jetweb-image-optimizer'), [$this, 'render_lazy_loading_field'], 'jetweb-image-optimizer', 'jetweb_io_delivery');
        add_settings_field('preserve_originals', __('Preserve Originals', 'jetweb-image-optimizer'), [$this, 'render_preserve_originals_field'], 'jetweb-image-optimizer', 'jetweb_io_delivery');
    }

    public function sanitize_settings($input) {
        $sanitized = [];
        $sanitized['output_format'] = in_array($input['output_format'] ?? '', ['webp', 'avif', 'both']) ? $input['output_format'] : 'webp';
        $sanitized['webp_quality'] = intval(min(100, max(1, $input['webp_quality'] ?? 82)));
        $sanitized['avif_quality'] = intval(min(100, max(1, $input['avif_quality'] ?? 65)));
        $sanitized['compress_originals'] = !empty($input['compress_originals']);
        $sanitized['jpeg_quality'] = intval(min(100, max(1, $input['jpeg_quality'] ?? 82)));
        $sanitized['png_compression'] = intval(min(9, max(0, $input['png_compression'] ?? 9)));
        $sanitized['max_width'] = intval(max(0, $input['max_width'] ?? 2560));
        $sanitized['max_height'] = intval(max(0, $input['max_height'] ?? 2560));
        $sanitized['preserve_originals'] = !empty($input['preserve_originals']);
        $sanitized['auto_serve'] = !empty($input['auto_serve']);
        $sanitized['lazy_loading'] = !empty($input['lazy_loading']);
        return $sanitized;
    }

    // ---- Field Renderers ----

    public function render_format_field() {
        $options = get_option('jetweb_io_settings', []);
        $value = $options['output_format'] ?? 'webp';
        $supported = JetWeb_IO_Converter::get_supported_formats();
        ?>
        <select name="jetweb_io_settings[output_format]">
            <option value="webp" <?php selected($value, 'webp'); ?>>WebP <?php echo isset($supported['webp']) ? '✓' : '✗ (not supported)'; ?></option>
            <option value="avif" <?php selected($value, 'avif'); ?>>AVIF <?php echo isset($supported['avif']) ? '✓' : '✗ (not supported)'; ?></option>
            <option value="both" <?php selected($value, 'both'); ?>>Both (WebP + AVIF)</option>
        </select>
        <p class="description"><?php _e('AVIF offers ~20% better compression than WebP but requires newer browsers. "Both" creates both formats and serves the best one each browser supports.', 'jetweb-image-optimizer'); ?></p>
        <?php
    }

    public function render_webp_quality_field() {
        $options = get_option('jetweb_io_settings', []);
        $value = $options['webp_quality'] ?? 82;
        ?>
        <input type="range" name="jetweb_io_settings[webp_quality]" min="1" max="100" value="<?php echo esc_attr($value); ?>" oninput="this.nextElementSibling.value=this.value">
        <output><?php echo esc_html($value); ?></output>
        <p class="description"><?php _e('Recommended: 75-85. Lower = smaller files, higher = better quality.', 'jetweb-image-optimizer'); ?></p>
        <?php
    }

    public function render_avif_quality_field() {
        $options = get_option('jetweb_io_settings', []);
        $value = $options['avif_quality'] ?? 65;
        ?>
        <input type="range" name="jetweb_io_settings[avif_quality]" min="1" max="100" value="<?php echo esc_attr($value); ?>" oninput="this.nextElementSibling.value=this.value">
        <output><?php echo esc_html($value); ?></output>
        <p class="description"><?php _e('Recommended: 50-70. AVIF achieves great quality at lower values.', 'jetweb-image-optimizer'); ?></p>
        <?php
    }

    public function render_compress_originals_field() {
        $options = get_option('jetweb_io_settings', []);
        $checked = $options['compress_originals'] ?? true;
        ?>
        <label>
            <input type="checkbox" name="jetweb_io_settings[compress_originals]" value="1" <?php checked($checked); ?>>
            <?php _e('Also compress the original JPEG/PNG files on upload', 'jetweb-image-optimizer'); ?>
        </label>
        <?php
    }

    public function render_jpeg_quality_field() {
        $options = get_option('jetweb_io_settings', []);
        $value = $options['jpeg_quality'] ?? 82;
        ?>
        <input type="range" name="jetweb_io_settings[jpeg_quality]" min="1" max="100" value="<?php echo esc_attr($value); ?>" oninput="this.nextElementSibling.value=this.value">
        <output><?php echo esc_html($value); ?></output>
        <?php
    }

    public function render_max_dimensions_field() {
        $options = get_option('jetweb_io_settings', []);
        ?>
        <label>
            <?php _e('Width:', 'jetweb-image-optimizer'); ?>
            <input type="number" name="jetweb_io_settings[max_width]" value="<?php echo esc_attr($options['max_width'] ?? 2560); ?>" min="0" style="width:80px">
        </label>
        &times;
        <label>
            <?php _e('Height:', 'jetweb-image-optimizer'); ?>
            <input type="number" name="jetweb_io_settings[max_height]" value="<?php echo esc_attr($options['max_height'] ?? 2560); ?>" min="0" style="width:80px">
        </label>
        <p class="description"><?php _e('Resize images exceeding these dimensions on upload. Set to 0 to disable.', 'jetweb-image-optimizer'); ?></p>
        <?php
    }

    public function render_auto_serve_field() {
        $options = get_option('jetweb_io_settings', []);
        ?>
        <label>
            <input type="checkbox" name="jetweb_io_settings[auto_serve]" value="1" <?php checked($options['auto_serve'] ?? true); ?>>
            <?php _e('Automatically serve WebP/AVIF to supporting browsers using <picture> elements', 'jetweb-image-optimizer'); ?>
        </label>
        <?php
    }

    public function render_lazy_loading_field() {
        $options = get_option('jetweb_io_settings', []);
        ?>
        <label>
            <input type="checkbox" name="jetweb_io_settings[lazy_loading]" value="1" <?php checked($options['lazy_loading'] ?? true); ?>>
            <?php _e('Add native lazy loading to images', 'jetweb-image-optimizer'); ?>
        </label>
        <?php
    }

    public function render_preserve_originals_field() {
        $options = get_option('jetweb_io_settings', []);
        ?>
        <label>
            <input type="checkbox" name="jetweb_io_settings[preserve_originals]" value="1" <?php checked($options['preserve_originals'] ?? true); ?>>
            <?php _e('Keep backups of original files (allows restoring later)', 'jetweb-image-optimizer'); ?>
        </label>
        <?php
    }

    // ---- Settings Page ----

    public function render_settings_page() {
        $stats = new JetWeb_IO_Stats();
        $summary = $stats->get_summary();
        $supported = JetWeb_IO_Converter::get_supported_formats();
        ?>
        <div class="wrap">
            <h1><?php _e('JetWeb Image Optimizer', 'jetweb-image-optimizer'); ?></h1>

            <!-- Stats Dashboard -->
            <div class="jetweb-io-stats-grid" style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin:20px 0;">
                <div class="jetweb-io-stat-card" style="background:#fff;padding:20px;border:1px solid #ccd0d4;border-radius:8px;text-align:center;">
                    <div style="font-size:32px;font-weight:700;color:#0073aa;"><?php echo esc_html($summary['total_images']); ?></div>
                    <div style="color:#666;margin-top:4px;"><?php _e('Images Optimized', 'jetweb-image-optimizer'); ?></div>
                </div>
                <div class="jetweb-io-stat-card" style="background:#fff;padding:20px;border:1px solid #ccd0d4;border-radius:8px;text-align:center;">
                    <div style="font-size:32px;font-weight:700;color:#00a32a;"><?php echo esc_html($summary['total_saved_readable']); ?></div>
                    <div style="color:#666;margin-top:4px;"><?php _e('Space Saved', 'jetweb-image-optimizer'); ?></div>
                </div>
                <div class="jetweb-io-stat-card" style="background:#fff;padding:20px;border:1px solid #ccd0d4;border-radius:8px;text-align:center;">
                    <div style="font-size:32px;font-weight:700;color:#d63638;"><?php echo esc_html($summary['avg_savings']); ?>%</div>
                    <div style="color:#666;margin-top:4px;"><?php _e('Avg. Savings', 'jetweb-image-optimizer'); ?></div>
                </div>
                <div class="jetweb-io-stat-card" style="background:#fff;padding:20px;border:1px solid #ccd0d4;border-radius:8px;text-align:center;">
                    <div style="font-size:14px;font-weight:600;margin-bottom:6px;"><?php _e('Server Support', 'jetweb-image-optimizer'); ?></div>
                    <div>
                        <span style="padding:3px 8px;border-radius:4px;font-size:12px;background:<?php echo isset($supported['webp']) ? '#d4edda' : '#f8d7da'; ?>;color:<?php echo isset($supported['webp']) ? '#155724' : '#721c24'; ?>;">
                            WebP <?php echo isset($supported['webp']) ? '✓ (' . esc_html($supported['webp']) . ')' : '✗'; ?>
                        </span>
                        <span style="padding:3px 8px;border-radius:4px;font-size:12px;background:<?php echo isset($supported['avif']) ? '#d4edda' : '#f8d7da'; ?>;color:<?php echo isset($supported['avif']) ? '#155724' : '#721c24'; ?>;">
                            AVIF <?php echo isset($supported['avif']) ? '✓ (' . esc_html($supported['avif']) . ')' : '✗'; ?>
                        </span>
                    </div>
                </div>
            </div>

            <div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;">
                <div>
                    <form method="post" action="options.php">
                        <?php
                        settings_fields('jetweb_io_settings_group');
                        do_settings_sections('jetweb-image-optimizer');
                        submit_button();
                        ?>
                    </form>
                </div>
                <div>
                    <div style="background:#fff;padding:20px;border:1px solid #ccd0d4;border-radius:8px;">
                        <h3 style="margin-top:0;"><?php _e('Bulk Optimize', 'jetweb-image-optimizer'); ?></h3>
                        <p><?php _e('Optimize all existing images in your media library.', 'jetweb-image-optimizer'); ?></p>
                        <div id="jetweb-io-bulk-progress" style="display:none;margin-bottom:12px;">
                            <div style="background:#e0e0e0;border-radius:4px;overflow:hidden;">
                                <div id="jetweb-io-progress-bar" style="background:#0073aa;height:20px;width:0%;transition:width 0.3s;border-radius:4px;"></div>
                            </div>
                            <p id="jetweb-io-progress-text" style="margin:8px 0 0;font-size:13px;color:#666;"></p>
                        </div>
                        <button type="button" id="jetweb-io-bulk-start" class="button button-primary"><?php _e('Start Bulk Optimization', 'jetweb-image-optimizer'); ?></button>
                        <button type="button" id="jetweb-io-bulk-stop" class="button" style="display:none;"><?php _e('Stop', 'jetweb-image-optimizer'); ?></button>
                    </div>

                    <div style="background:#fff;padding:20px;border:1px solid #ccd0d4;border-radius:8px;margin-top:16px;">
                        <h3 style="margin-top:0;"><?php _e('Browser Support', 'jetweb-image-optimizer'); ?></h3>
                        <table class="widefat" style="border:0;">
                            <tr><td><strong>WebP</strong></td><td>Chrome, Firefox, Safari 14+, Edge</td></tr>
                            <tr><td><strong>AVIF</strong></td><td>Chrome 85+, Firefox 93+, Safari 16.4+</td></tr>
                        </table>
                        <p class="description" style="margin-top:10px;"><?php _e('Unsupported browsers automatically fall back to the original format.', 'jetweb-image-optimizer'); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    // ---- Media Library Column ----

    public function add_media_column($columns) {
        $columns['jetweb_io'] = __('Image Optimizer', 'jetweb-image-optimizer');
        return $columns;
    }

    public function render_media_column($column_name, $attachment_id) {
        if ($column_name !== 'jetweb_io') {
            return;
        }

        $file = get_attached_file($attachment_id);
        if (!$file || !wp_attachment_is_image($attachment_id)) {
            echo '—';
            return;
        }

        $stats = new JetWeb_IO_Stats();
        $conversion = $stats->get_attachment_stats($attachment_id);

        if ($conversion) {
            $savings = round($conversion->savings_percent, 1);
            $color = $savings > 50 ? '#00a32a' : ($savings > 20 ? '#dba617' : '#d63638');
            echo '<span style="color:' . $color . ';font-weight:600;">' . esc_html($savings) . '% saved</span>';
            echo '<br><small>' . esc_html(strtoupper($conversion->format)) . '</small>';
            echo '<br><button class="button button-small jetweb-io-restore" data-id="' . esc_attr($attachment_id) . '">' . __('Restore', 'jetweb-image-optimizer') . '</button>';
        } else {
            echo '<button class="button button-small button-primary jetweb-io-optimize" data-id="' . esc_attr($attachment_id) . '">' . __('Optimize', 'jetweb-image-optimizer') . '</button>';
        }
    }

    // ---- AJAX Handlers ----

    public function ajax_optimize_single() {
        check_ajax_referer('jetweb_io_nonce', 'nonce');

        if (!current_user_can('upload_files')) {
            wp_send_json_error('Permission denied');
        }

        $attachment_id = intval($_POST['attachment_id'] ?? 0);
        if (!$attachment_id) {
            wp_send_json_error('Invalid attachment ID');
        }

        $file = get_attached_file($attachment_id);
        if (!$file || !file_exists($file)) {
            wp_send_json_error('File not found');
        }

        $options = get_option('jetweb_io_settings', []);
        $converter = new JetWeb_IO_Converter();
        $compressor = new JetWeb_IO_Compressor();
        $stats_handler = new JetWeb_IO_Stats();

        // Compress original
        if (!empty($options['compress_originals'])) {
            $compressor->compress_file($file);
        }

        // Convert to modern format(s)
        $converted = $converter->convert($file, $options);

        if ($converted) {
            $stats_handler->record_conversion($attachment_id, $file, $converted);

            // Also process thumbnails
            $metadata = wp_get_attachment_metadata($attachment_id);
            if (!empty($metadata['sizes'])) {
                $dir = dirname($file);
                foreach ($metadata['sizes'] as $size_data) {
                    $thumb = trailingslashit($dir) . $size_data['file'];
                    if (file_exists($thumb)) {
                        $thumb_converted = $converter->convert($thumb, $options);
                        if ($thumb_converted) {
                            $stats_handler->record_conversion($attachment_id, $thumb, $thumb_converted);
                        }
                    }
                }
            }

            wp_send_json_success([
                'message' => __('Image optimized successfully!', 'jetweb-image-optimizer'),
                'stats' => $stats_handler->get_attachment_stats($attachment_id),
            ]);
        }

        wp_send_json_error('Conversion failed');
    }

    public function ajax_restore_single() {
        check_ajax_referer('jetweb_io_nonce', 'nonce');

        if (!current_user_can('upload_files')) {
            wp_send_json_error('Permission denied');
        }

        $attachment_id = intval($_POST['attachment_id'] ?? 0);
        $file = get_attached_file($attachment_id);

        if (!$file) {
            wp_send_json_error('File not found');
        }

        $compressor = new JetWeb_IO_Compressor();
        $stats = new JetWeb_IO_Stats();

        if ($compressor->restore_original($file)) {
            // Delete converted files
            foreach (['webp', 'avif'] as $fmt) {
                $converted = pathinfo($file, PATHINFO_DIRNAME) . '/' . pathinfo($file, PATHINFO_FILENAME) . '.' . $fmt;
                if (file_exists($converted)) {
                    @unlink($converted);
                }
            }

            $stats->delete_attachment_stats($attachment_id);
            wp_send_json_success(['message' => __('Original restored.', 'jetweb-image-optimizer')]);
        }

        wp_send_json_error('No backup found');
    }

    public function ajax_get_stats() {
        check_ajax_referer('jetweb_io_nonce', 'nonce');
        $stats = new JetWeb_IO_Stats();
        wp_send_json_success($stats->get_summary());
    }

    // ---- Assets & Links ----

    public function enqueue_assets($hook) {
        if ($hook === 'settings_page_jetweb-image-optimizer' || $hook === 'upload.php') {
            wp_enqueue_script(
                'jetweb-io-admin',
                JETWEB_IO_PLUGIN_URL . 'assets/admin.js',
                ['jquery'],
                JETWEB_IO_VERSION,
                true
            );

            wp_localize_script('jetweb-io-admin', 'jetwebIO', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('jetweb_io_nonce'),
                'i18n'     => [
                    'optimizing' => __('Optimizing...', 'jetweb-image-optimizer'),
                    'restoring'  => __('Restoring...', 'jetweb-image-optimizer'),
                    'complete'   => __('Complete!', 'jetweb-image-optimizer'),
                    'error'      => __('Error occurred', 'jetweb-image-optimizer'),
                ],
            ]);
        }
    }

    public function add_action_links($links) {
        $settings_link = '<a href="' . admin_url('options-general.php?page=jetweb-image-optimizer') . '">' . __('Settings', 'jetweb-image-optimizer') . '</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
}
