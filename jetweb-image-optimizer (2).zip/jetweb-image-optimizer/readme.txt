=== JetWeb Image Optimizer ===
Contributors: jetweb
Tags: image optimization, webp, avif, compression, performance
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Automatically converts and compresses images to WebP & AVIF for faster page loads and better Core Web Vitals.

== Description ==

JetWeb Image Optimizer automatically converts your uploaded images to modern web formats (WebP and AVIF) and compresses them for optimal performance — all on your own server with zero external API dependencies.

**Key Features:**

* **Auto-conversion on upload** — Every image is automatically converted to WebP and/or AVIF
* **Smart browser delivery** — Uses `<picture>` elements to serve the best format each browser supports
* **Bulk optimizer** — Convert your entire existing media library with one click
* **Original compression** — Optionally compress JPEG/PNG originals too
* **Auto-resize** — Downscale oversized uploads to configurable max dimensions
* **Backup & restore** — Original files are backed up so you can revert any time
* **Stats dashboard** — Track total space saved and average compression ratios
* **Media library integration** — Optimize/restore individual images from the media list
* **Native lazy loading** — Adds `loading="lazy"` for below-the-fold images
* **Zero external services** — All processing happens on your server

**Format Support:**

| Format | Compression vs JPEG | Browser Support |
|--------|-------------------|-----------------|
| WebP   | ~25-35% smaller   | 97%+ of browsers |
| AVIF   | ~40-50% smaller   | 92%+ of browsers |

**Requirements:**

* PHP 7.4+ with GD or Imagick extension
* WebP support in GD/Imagick (standard on most modern hosts)
* AVIF support requires PHP 8.1+ with GD, or Imagick with AVIF support, or `avifenc` CLI tool

== Installation ==

1. Upload the `jetweb-image-optimizer` folder to `/wp-content/plugins/`
2. Activate the plugin through the **Plugins** menu
3. Go to **Settings → Image Optimizer** to configure
4. New uploads will be automatically optimized
5. Use **Bulk Optimize** to process existing images

== Frequently Asked Questions ==

= Will this break my existing images? =
No. Original images are backed up and the plugin serves modern formats only to browsers that support them. Unsupported browsers see the original.

= Does this work with page builders? =
Yes. The plugin hooks into WordPress's image output filters, so it works with Elementor, Divi, Beaver Builder, Gutenberg, and the Classic Editor.

= What happens if I deactivate the plugin? =
Your original images remain untouched. The converted WebP/AVIF files stay on disk but won't be served. You can safely delete them.

= Can I use both WebP and AVIF? =
Yes! Set the output format to "Both" and the plugin will generate both versions, serving AVIF to browsers that support it and WebP to others.

== Changelog ==

= 1.0.0 =
* Initial release
* WebP and AVIF conversion
* Bulk optimizer
* Smart browser-based delivery with `<picture>` elements
* Media library integration
* Stats dashboard
* Backup and restore system
