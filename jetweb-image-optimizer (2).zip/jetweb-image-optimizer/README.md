# JetWeb Image Optimizer

![WordPress](https://img.shields.io/badge/WordPress-5.8%2B-blue?logo=wordpress)
![PHP](https://img.shields.io/badge/PHP-7.4%2B-777BB4?logo=php&logoColor=white)
![License](https://img.shields.io/badge/License-GPLv2-green)
![Version](https://img.shields.io/badge/Version-1.0.0-orange)

A WordPress plugin that **automatically converts and compresses images to WebP & AVIF** — entirely on your own server, with zero external API dependencies or subscriptions.

---

## Why This Plugin?

Most image optimization plugins rely on paid cloud APIs. JetWeb Image Optimizer runs **100% locally** on your server, giving you:

- **No usage limits** — optimize unlimited images
- **No recurring fees** — free forever
- **No data leaving your server** — full privacy
- **Instant processing** — no queue waiting

## Features

| Feature | Description |
|---|---|
| **Auto-Convert on Upload** | Every image is automatically converted to WebP and/or AVIF |
| **Smart Browser Delivery** | Serves AVIF → WebP → original via `<picture>` elements |
| **Bulk Optimizer** | One-click conversion of your entire existing media library |
| **Original Compression** | Optionally compress source JPEG/PNG files too |
| **Auto-Resize** | Downscale oversized uploads to configurable max dimensions |
| **Backup & Restore** | Originals are preserved — revert any image at any time |
| **Stats Dashboard** | Track total space saved, image count, and avg compression |
| **Media Library Integration** | Optimize or restore individual images from the media list |
| **Lazy Loading** | Native `loading="lazy"` for below-the-fold images |

## Format Comparison

| Format | Size Reduction vs JPEG | Browser Support |
|--------|----------------------|-----------------|
| **WebP** | ~25–35% smaller | 97%+ of browsers |
| **AVIF** | ~40–50% smaller | 92%+ of browsers |

Unsupported browsers automatically fall back to the original image — nothing breaks.

## Screenshots

> _Coming soon — screenshots of the settings dashboard, bulk optimizer, and media library column._

## Requirements

- **WordPress** 5.8+
- **PHP** 7.4+ with **GD** or **Imagick** extension
- **WebP**: Supported on virtually all modern PHP hosts
- **AVIF**: Requires one of the following:
  - PHP 8.1+ with GD
  - Imagick compiled with AVIF support
  - `avifenc` CLI tool installed on the server

## Installation

### Manual Install

1. Download the [latest release](https://github.com/YOUR_USERNAME/jetweb-image-optimizer/releases)
2. In WordPress, go to **Plugins → Add New → Upload Plugin**
3. Upload the `.zip` file and activate

### From Source

```bash
git clone https://github.com/YOUR_USERNAME/jetweb-image-optimizer.git
cp -r jetweb-image-optimizer /path/to/wordpress/wp-content/plugins/
```

Then activate from **Plugins** in your WordPress admin.

## Configuration

Navigate to **Settings → Image Optimizer** after activation.

### Conversion Settings

- **Output Format** — Choose WebP, AVIF, or Both
- **WebP Quality** — Default `82` (recommended 75–85)
- **AVIF Quality** — Default `65` (recommended 50–70; AVIF achieves great quality at lower values)

### Compression Settings

- **Compress Originals** — Also optimize the source JPEG/PNG on upload
- **JPEG Quality** — Compression level for original JPEGs
- **Max Dimensions** — Auto-resize images exceeding a width/height limit

### Delivery Settings

- **Auto-Serve Modern Formats** — Rewrite `<img>` tags to `<picture>` elements
- **Lazy Loading** — Add native `loading="lazy"` attribute
- **Preserve Originals** — Keep backups for one-click restore

## How It Works

```
User uploads photo.jpg
        │
        ▼
┌─────────────────────┐
│  Compress Original   │  ← Optional: lossy JPEG/PNG compression
│  (backup created)    │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Convert to WebP     │  → photo.webp
│  Convert to AVIF     │  → photo.avif
│  (all sizes/thumbs)  │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Frontend Delivery   │
│                     │
│  Browser: AVIF? ──→ photo.avif
│  Browser: WebP? ──→ photo.webp
│  Fallback:      ──→ photo.jpg
└─────────────────────┘
```

## Plugin Structure

```
jetweb-image-optimizer/
├── jetweb-image-optimizer.php   # Main plugin file & bootstrap
├── includes/
│   ├── class-converter.php      # WebP/AVIF conversion (GD, Imagick, CLI)
│   ├── class-compressor.php     # JPEG/PNG compression & resize
│   ├── class-frontend.php       # <picture> element delivery
│   ├── class-admin.php          # Settings page & media library column
│   ├── class-bulk-optimizer.php # Batch processing via AJAX
│   └── class-stats.php          # Optimization statistics tracking
├── assets/
│   └── admin.js                 # Admin UI & bulk optimizer JS
└── readme.txt                   # WordPress.org readme
```

## Compatibility

Tested with:

- **Editors**: Gutenberg, Classic Editor
- **Page Builders**: Elementor, Divi, Beaver Builder
- **Caching Plugins**: WP Super Cache, W3 Total Cache, LiteSpeed Cache
- **CDNs**: Cloudflare, BunnyCDN, KeyCDN

## Roadmap

- [ ] WP-CLI support (`wp jetweb optimize --all`)
- [ ] Lossless conversion mode
- [ ] Per-image quality override in media library
- [ ] REST API endpoints
- [ ] Multisite support
- [ ] Conversion queue with background processing (Action Scheduler)

## Contributing

Contributions are welcome! Please open an issue first to discuss what you'd like to change.

1. Fork the repo
2. Create your feature branch (`git checkout -b feature/my-feature`)
3. Commit your changes (`git commit -m 'Add my feature'`)
4. Push to the branch (`git push origin feature/my-feature`)
5. Open a Pull Request

## License

This project is licensed under the [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html).

## Author

**Griffin Smith** — [griffinsmith.io](https://griffinsmith.io)
