<?php
/**
 * Plugin Name: JetWeb Image Optimizer
 * Plugin URI: https://griffinsmith.io
 * Description: Automatically converts and compresses images to modern web formats (WebP & AVIF) for faster page loads and better Core Web Vitals.
 * Version: 1.0.0
 * Author: Griffin Smith
 * Author URI: https://griffinsmith.io
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: jetweb-image-optimizer
 * Requires PHP: 7.4
 * Requires at least: 5.8
 */

if (!defined('ABSPATH')) {
    exit;
}

define('JETWEB_IO_VERSION', '1.0.0');
define('JETWEB_IO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('JETWEB_IO_PLUGIN_URL', plugin_dir_url(__FILE__));
define('JETWEB_IO_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Autoload classes
spl_autoload_register(function ($class) {
    $prefix = 'JetWeb_IO_';
    if (strpos($class, $prefix) !== 0) {
        return;
    }
    $relative_class = substr($class, strlen($prefix));
    $file = JETWEB_IO_PLUGIN_DIR . 'includes/class-' . strtolower(str_replace('_', '-', $relative_class)) . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

/**
 * Main Plugin Class
 */
final class JetWeb_Image_Optimizer {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }

    private function load_dependencies() {
        require_once JETWEB_IO_PLUGIN_DIR . 'includes/class-converter.php';
        require_once JETWEB_IO_PLUGIN_DIR . 'includes/class-compressor.php';
        require_once JETWEB_IO_PLUGIN_DIR . 'includes/class-admin.php';
        require_once JETWEB_IO_PLUGIN_DIR . 'includes/class-frontend.php';
        require_once JETWEB_IO_PLUGIN_DIR . 'includes/class-bulk-optimizer.php';
        require_once JETWEB_IO_PLUGIN_DIR . 'includes/class-stats.php';
    }

    private function init_hooks() {
        // Activation / Deactivation
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);

        // Initialize components
        add_action('init', [$this, 'init']);
        add_action('admin_init', [$this, 'check_requirements']);
    }

    public function init() {
        // Auto-convert on upload
        $converter = new JetWeb_IO_Converter();
        $compressor = new JetWeb_IO_Compressor();

        // Hook into upload pipeline
        add_filter('wp_handle_upload', [$this, 'handle_upload'], 10, 2);
        add_filter('wp_generate_attachment_metadata', [$this, 'process_attachment'], 10, 2);

        // Frontend delivery
        $frontend = new JetWeb_IO_Frontend();
        $frontend->init();

        // Admin
        if (is_admin()) {
            $admin = new JetWeb_IO_Admin();
            $admin->init();

            $bulk = new JetWeb_IO_Bulk_Optimizer();
            $bulk->init();
        }
    }

    /**
     * Process newly uploaded images
     */
    public function handle_upload($upload, $context) {
        // Store original for potential revert
        if (isset($upload['file']) && $this->is_supported_image($upload['file'])) {
            $options = get_option('jetweb_io_settings', []);
            $compress_originals = $options['compress_originals'] ?? true;

            if ($compress_originals) {
                $compressor = new JetWeb_IO_Compressor();
                $compressor->compress_file($upload['file']);
            }
        }
        return $upload;
    }

    /**
     * Generate WebP/AVIF versions for all image sizes
     */
    public function process_attachment($metadata, $attachment_id) {
        if (!is_array($metadata) || empty($metadata['file'])) {
            return $metadata;
        }

        $upload_dir = wp_upload_dir();
        $base_dir = trailingslashit($upload_dir['basedir']);
        $file_path = $base_dir . $metadata['file'];

        if (!$this->is_supported_image($file_path)) {
            return $metadata;
        }

        $options = get_option('jetweb_io_settings', []);
        $converter = new JetWeb_IO_Converter();
        $stats = new JetWeb_IO_Stats();

        // Convert main image
        $converted = $converter->convert($file_path, $options);
        if ($converted) {
            $stats->record_conversion($attachment_id, $file_path, $converted);
        }

        // Convert all thumbnail sizes
        if (!empty($metadata['sizes'])) {
            $file_dir = dirname($file_path);
            foreach ($metadata['sizes'] as $size_name => $size_data) {
                $thumb_path = trailingslashit($file_dir) . $size_data['file'];
                if (file_exists($thumb_path)) {
                    $thumb_converted = $converter->convert($thumb_path, $options);
                    if ($thumb_converted) {
                        $stats->record_conversion($attachment_id, $thumb_path, $thumb_converted);
                    }
                }
            }
        }

        return $metadata;
    }

    private function is_supported_image($file_path) {
        $supported = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'tiff', 'tif'];
        $ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        return in_array($ext, $supported);
    }

    public function activate() {
        // Default settings
        $defaults = [
            'output_format'      => 'webp',         // webp, avif, both
            'webp_quality'       => 82,
            'avif_quality'       => 65,
            'compress_originals' => true,
            'jpeg_quality'       => 82,
            'png_compression'    => 9,
            'max_width'          => 2560,
            'max_height'         => 2560,
            'preserve_originals' => true,
            'auto_serve'         => true,            // Auto-serve modern formats
            'lazy_loading'       => true,
            'delete_on_uninstall'=> false,
        ];

        if (!get_option('jetweb_io_settings')) {
            add_option('jetweb_io_settings', $defaults);
        }

        // Create backup directory
        $upload_dir = wp_upload_dir();
        $backup_dir = trailingslashit($upload_dir['basedir']) . 'jetweb-io-backups';
        if (!file_exists($backup_dir)) {
            wp_mkdir_p($backup_dir);
        }

        // Stats table
        $this->create_stats_table();

        flush_rewrite_rules();
    }

    public function deactivate() {
        flush_rewrite_rules();
    }

    private function create_stats_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'jetweb_io_stats';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            attachment_id bigint(20) NOT NULL,
            original_path varchar(500) NOT NULL,
            converted_path varchar(500) DEFAULT NULL,
            original_size bigint(20) NOT NULL DEFAULT 0,
            converted_size bigint(20) NOT NULL DEFAULT 0,
            savings_percent float NOT NULL DEFAULT 0,
            format varchar(10) NOT NULL DEFAULT 'webp',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY attachment_id (attachment_id),
            KEY format (format)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    public function check_requirements() {
        $notices = [];

        if (!extension_loaded('gd') && !extension_loaded('imagick')) {
            $notices[] = __('JetWeb Image Optimizer requires GD or Imagick PHP extension to be installed.', 'jetweb-image-optimizer');
        }

        if (extension_loaded('gd')) {
            $gd_info = gd_info();
            if (empty($gd_info['WebP Support'])) {
                $notices[] = __('Your GD library does not support WebP. Please update PHP or install Imagick.', 'jetweb-image-optimizer');
            }
        }

        foreach ($notices as $notice) {
            add_action('admin_notices', function () use ($notice) {
                echo '<div class="notice notice-error"><p>' . esc_html($notice) . '</p></div>';
            });
        }
    }
}

// Boot the plugin
JetWeb_Image_Optimizer::get_instance();
