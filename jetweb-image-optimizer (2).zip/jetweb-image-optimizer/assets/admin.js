(function($) {
    'use strict';

    // ---- Single Image Optimize/Restore (Media Library) ----

    $(document).on('click', '.jetweb-io-optimize', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var id = $btn.data('id');

        $btn.prop('disabled', true).text(jetwebIO.i18n.optimizing);

        $.post(jetwebIO.ajax_url, {
            action: 'jetweb_io_optimize_single',
            nonce: jetwebIO.nonce,
            attachment_id: id
        }, function(response) {
            if (response.success) {
                var stats = response.data.stats;
                var savings = parseFloat(stats.savings_percent).toFixed(1);
                $btn.replaceWith(
                    '<span style="color:#00a32a;font-weight:600;">' + savings + '% saved</span>' +
                    '<br><small>' + stats.format.toUpperCase() + '</small>' +
                    '<br><button class="button button-small jetweb-io-restore" data-id="' + id + '">Restore</button>'
                );
            } else {
                $btn.prop('disabled', false).text(jetwebIO.i18n.error);
            }
        }).fail(function() {
            $btn.prop('disabled', false).text(jetwebIO.i18n.error);
        });
    });

    $(document).on('click', '.jetweb-io-restore', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var id = $btn.data('id');

        if (!confirm('Restore original image? Converted versions will be deleted.')) {
            return;
        }

        $btn.prop('disabled', true).text(jetwebIO.i18n.restoring);

        $.post(jetwebIO.ajax_url, {
            action: 'jetweb_io_restore_single',
            nonce: jetwebIO.nonce,
            attachment_id: id
        }, function(response) {
            if (response.success) {
                $btn.parent().html(
                    '<button class="button button-small button-primary jetweb-io-optimize" data-id="' + id + '">Optimize</button>'
                );
            } else {
                $btn.prop('disabled', false).text(jetwebIO.i18n.error);
            }
        });
    });

    // ---- Bulk Optimizer ----

    var bulkRunning = false;
    var bulkQueue = [];
    var bulkProcessed = 0;
    var bulkTotal = 0;
    var BATCH_SIZE = 3;

    $('#jetweb-io-bulk-start').on('click', function() {
        var $startBtn = $(this);
        var $stopBtn = $('#jetweb-io-bulk-stop');
        var $progress = $('#jetweb-io-bulk-progress');

        $startBtn.prop('disabled', true);
        $stopBtn.show();
        $progress.show();

        bulkRunning = true;
        bulkProcessed = 0;

        // First, get unoptimized images
        $.post(jetwebIO.ajax_url, {
            action: 'jetweb_io_bulk_get_images',
            nonce: jetwebIO.nonce
        }, function(response) {
            if (!response.success || !response.data.image_ids.length) {
                updateProgress(0, 0, 'All images are already optimized!');
                resetBulkUI();
                return;
            }

            bulkQueue = response.data.image_ids;
            bulkTotal = response.data.total;
            updateProgress(0, bulkTotal, 'Starting optimization...');
            processBatch();
        });
    });

    $('#jetweb-io-bulk-stop').on('click', function() {
        bulkRunning = false;
        resetBulkUI();
    });

    function processBatch() {
        if (!bulkRunning || bulkQueue.length === 0) {
            if (bulkQueue.length === 0) {
                updateProgress(bulkTotal, bulkTotal, jetwebIO.i18n.complete);
            }
            resetBulkUI();
            return;
        }

        var batch = bulkQueue.splice(0, BATCH_SIZE);

        $.post(jetwebIO.ajax_url, {
            action: 'jetweb_io_bulk_optimize',
            nonce: jetwebIO.nonce,
            attachment_ids: batch
        }, function(response) {
            bulkProcessed += batch.length;
            var pct = Math.round((bulkProcessed / bulkTotal) * 100);
            var successCount = 0;

            if (response.success && response.data.results) {
                $.each(response.data.results, function(id, result) {
                    if (result.status === 'success') successCount++;
                });
            }

            updateProgress(bulkProcessed, bulkTotal,
                bulkProcessed + ' / ' + bulkTotal + ' processed (' + pct + '%)');

            // Continue with next batch
            setTimeout(processBatch, 200);
        }).fail(function() {
            bulkProcessed += batch.length;
            setTimeout(processBatch, 1000);
        });
    }

    function updateProgress(current, total, text) {
        var pct = total > 0 ? Math.round((current / total) * 100) : 0;
        $('#jetweb-io-progress-bar').css('width', pct + '%');
        $('#jetweb-io-progress-text').text(text);
    }

    function resetBulkUI() {
        bulkRunning = false;
        $('#jetweb-io-bulk-start').prop('disabled', false);
        $('#jetweb-io-bulk-stop').hide();
    }

})(jQuery);
